import React, { useEffect, useState } from "react";
import Dashboard from "../../components/Dashboard";
import { useApp } from '../../context/AppContext';
import { markLessonCompleted, updateUserCoins } from "../../utils/firebaseUtils";
import { toast } from "react-hot-toast";

const Lesson48 = () => {
  const { userData } = useApp();
  const lessonId = "lesson48";
  const [isCompleted, setIsCompleted] = useState(false);

  const [answeredQ1, setAnsweredQ1] = useState(false);
  const [answeredQ2, setAnsweredQ2] = useState(false);
  const [answeredQ3, setAnsweredQ3] = useState(false);

  const [selectedAnswers, setSelectedAnswers] = useState(() => {
    const saved = localStorage.getItem("lesson48-answers");
    return saved ? JSON.parse(saved) : {};
  });

  const [loadingDownload, setLoadingDownload] = useState(false);
  const [loadingShare, setLoadingShare] = useState(false);

  const handleAnswer = (question, answer) => {
    const correctAnswers = {
      q1: "C",
      q2: "C",
      q3: "A",
    };

    const isCorrect = correctAnswers[question] === answer;

    if (question === "q1" && !answeredQ1) setAnsweredQ1(true);
    if (question === "q2" && !answeredQ2) setAnsweredQ2(true);
    if (question === "q3" && !answeredQ3) setAnsweredQ3(true);

    setSelectedAnswers((prev) => {
      const updated = { ...prev, [question]: answer };
      localStorage.setItem("lesson48-answers", JSON.stringify(updated));
      return updated;
    });

    isCorrect ? toast.success("Correct!") : toast.error("Incorrect. Try again.");
  };

  const handleDownload = async () => {
    if (!userData) return toast.error("Login first!");
    if (loadingDownload) return;

    setLoadingDownload(true);
    try {
      await updateUserCoins(userData.uid, -10);
      toast.success("10 coins deducted. Download started!");
    } catch (error) {
      toast.error("Error updating coins");
    } finally {
      setLoadingDownload(false);
    }
  };

  const handleShare = async () => {
    if (!userData) return toast.error("Login first!");
    if (loadingShare) return;

    setLoadingShare(true);
    try {
      await updateUserCoins(userData.uid, -5);
      toast.success("5 coins deducted. Thanks for sharing!");
    } catch (error) {
      toast.error("Error updating coins");
    } finally {
      setLoadingShare(false);
    }
  };

  useEffect(() => {
    if (!isCompleted && answeredQ1 && answeredQ2 && answeredQ3) {
      markLessonCompleted(userData.uid, lessonId);
      updateUserCoins(userData.uid, 15);
      toast.success("Lesson complete! 🎉 15 coins added");
      setIsCompleted(true);
    }
  }, [answeredQ1, answeredQ2, answeredQ3, isCompleted, userData?.uid]);

  const getOptionStyle = (question, optionLetter) => {
    if (!selectedAnswers[question]) return "cursor-pointer";
    if (selectedAnswers[question] === optionLetter) {
      const correctAnswers = { q1: "C", q2: "C", q3: "A" };
      return correctAnswers[question] === optionLetter
        ? "bg-green-200 text-green-800"
        : "bg-red-200 text-red-800";
    }
    return "cursor-pointer";
  };

  return (
    <Dashboard>
      <div className="p-4 max-w-3xl mx-auto">
        <h1 className="text-2xl font-bold mb-4">Lesson 48: Introduction to Robotics</h1>
        <p className="mb-6">This lesson introduces basic robotics principles.</p>

        {/* Quiz */}
        <div className="bg-white p-4 rounded shadow">
          <h2 className="text-xl font-semibold mb-2">Mini Quiz</h2>

          {/* Question 1 */}
          <div className="mb-4">
            <p className="font-medium">1. What is a robot?</p>
            <ul className="space-y-2 mt-2">
              {["A", "B", "C", "D"].map((letter) => (
                <li
                  key={letter}
                  className={`p-2 rounded border ${getOptionStyle("q1", letter)}`}
                  onClick={() => handleAnswer("q1", letter)}
                >
                  {letter}. {
                    {
                      A: "A human-like machine",
                      B: "Any machine with wheels",
                      C: "A programmable machine that can perform tasks",
                      D: "An AI system",
                    }[letter]
                  }
                </li>
              ))}
            </ul>
          </div>

          {/* Question 2 */}
          <div className="mb-4">
            <p className="font-medium">2. Which component acts as the brain of a robot?</p>
            <ul className="space-y-2 mt-2">
              {["A", "B", "C", "D"].map((letter) => (
                <li
                  key={letter}
                  className={`p-2 rounded border ${getOptionStyle("q2", letter)}`}
                  onClick={() => handleAnswer("q2", letter)}
                >
                  {letter}. {
                    {
                      A: "Motor",
                      B: "Sensor",
                      C: "Microcontroller",
                      D: "Wheel",
                    }[letter]
                  }
                </li>
              ))}
            </ul>
          </div>

          {/* Question 3 */}
          <div className="mb-4">
            <p className="font-medium">3. What allows a robot to move?</p>
            <ul className="space-y-2 mt-2">
              {["A", "B", "C", "D"].map((letter) => (
                <li
                  key={letter}
                  className={`p-2 rounded border ${getOptionStyle("q3", letter)}`}
                  onClick={() => handleAnswer("q3", letter)}
                >
                  {letter}. {
                    {
                      A: "Motor",
                      B: "Battery",
                      C: "Sensor",
                      D: "Camera",
                    }[letter]
                  }
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="mt-6 flex gap-4 flex-wrap">
          <button
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded"
            onClick={handleDownload}
            disabled={loadingDownload}
          >
            {loadingDownload ? "Processing..." : "Download Materials (-10 coins)"}
          </button>

          <button
            className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded"
            onClick={handleShare}
            disabled={loadingShare}
          >
            {loadingShare ? "Sharing..." : "Share Lesson (-5 coins)"}
          </button>
        </div>

        <div className="mt-6 text-sm text-gray-600">
          Want more? <a href="/full-quiz" className="underline text-blue-500">Take the full quiz here</a>.
        </div>
      </div>
    </Dashboard>
  );
};

export default Lesson48;

